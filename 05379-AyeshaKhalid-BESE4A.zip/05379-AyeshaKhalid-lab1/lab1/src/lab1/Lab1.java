/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1;

/**
 *
 * @author khalid
 */

import java.util.Scanner;
import java.util.Random;
public class Lab1 {

      /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         matrix(1000,1000,1000);
    }
    
    
      public static void matrix(int rowsInA, int columnsInA, int columnsInB){
    
        
        
Random rand = new Random();

       
        int[][] a = new int[rowsInA][columnsInA];
        int[][] b = new int[columnsInA][columnsInB];
      
       int x;
       for (int i = 0; i < a.length; i++) {
           for (int j = 0; j < a[0].length; j++) {
                 x = rand.nextInt((100 - 2) + 1) + 2;
               
               a[i][j] = x;
           }
       }
       
       for (int i = 0; i < b.length; i++) {
           for (int j = 0; j < b[0].length; j++) {
                  x = rand.nextInt((100 - 2) + 1) + 2;
               b[i][j] = x;
           }
       }
       int[][] c = multiply(a, b);
       System.out.println("Product of A and B is");
       for (int i = 0; i < c.length; i++) {
           for (int j = 0; j < c[0].length; j++) {
               System.out.print(c[i][j] + " ");
           }
           System.out.println();
       }
   }

   public static int[][] multiply(int[][] a, int[][] b) {
       int rowsInA = a.length;
       int columnsInA = a[0].length; // same as rows in B
       int columnsInB = b[0].length;
       int[][] c = new int[rowsInA][columnsInB];
       for (int i = 0; i < rowsInA; i++) {
           for (int j = 0; j < columnsInB; j++) {
               for (int k = 0; k < columnsInA; k++) {
                   c[i][j] = c[i][j] + a[i][k] * b[k][j];
               }
           }
       }
       return c;
   }
    
}
//}
