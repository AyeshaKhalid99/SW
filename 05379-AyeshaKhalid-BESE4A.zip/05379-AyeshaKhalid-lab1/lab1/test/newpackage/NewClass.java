/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package newpackage;
import lab1.Lab1; 
import lab1.StrassenMul;
import org.junit.Test;
/**
 *StrassenMul
 * @author khalid
 */
public class NewClass {
    
    
     @Test(timeout=2000) public void test(){
         Lab1 l= new Lab1();
         l.matrix(20,20,20); } 
     
     @Test(timeout=2000) public void test1(){ 
         Lab1 l= new Lab1();
         l.matrix(20,20,20); }
    
        @Test(timeout=2000) public void test2(){
         StrassenMul s= new StrassenMul();
         s.matrix2(10); } 
     
     @Test(timeout=2000) public void test3(){ 
         StrassenMul s= new StrassenMul();
         s.matrix2(10); }
    
    
}
