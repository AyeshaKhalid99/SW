/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab3server;

import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
/**
 *
 * @author khalid
 */
public class Lab3Server {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int port= 9001;   
        Socket sock=null; 
    try{
        ServerSocket s_sock = new ServerSocket(port);  //create server socket
        System.out.println("Server is up and listening!");
        while(true){                              //keep on listening for other clients
            sock = s_sock.accept();                //accept client connection
            Handle_Client client = new Handle_Client(sock);
            Thread t = new Thread(client);          //create new thread for each client so that each client can be handled in parallel
            t.start();                              
        }//while
    }//try
    catch(Exception e){
        System.out.println("Sorry! An an error occurred while connecting with the client!");
    }//catch
        
    }//main  
}//class
class Handle_Client  implements Runnable { 
    Socket sock;
    BufferedReader in = null;
    PrintWriter out = null;
    FileInputStream fis = null;
    ObjectInputStream objectStream=null;
    ObjectOutputStream objoutput=null;
    private Socket client;
    int i=0;
    String path="";
    Handle_Client(Socket sock) throws Exception{
      this.client=sock;
      this.sock = sock;
    }
  
    public void run () {
        String s=null;
        try{
        objectStream = new ObjectInputStream(sock.getInputStream());
        objoutput = new ObjectOutputStream(sock.getOutputStream());
    }//try
    catch(Exception e2){
        System.out.println("Error while opening data stream!");
    }//catch
    try{
        note note1=new note();
        try{
            note1=(note)objectStream.readObject();
            if(note1.note_data!=null){  //if faile is to be saved
                PrintWriter writer = new PrintWriter(note1.file_name+".txt", "UTF-8");
                writer.println(note1.note_data);
                writer.close();
            }
            else{
                File f = new File(note1.file_name+".txt");
            if(f.isFile()){         //if file exists
                fis=new FileInputStream(f);
                DataInputStream din = new DataInputStream(fis);
                int len = (int) f.length();
                byte[] buf = new byte[len];
                din.readFully(buf);
                String st = new String(buf);//read file bytes and send to client
                note note2=new note();
                note2.note_data=st;
                objoutput.writeObject(note2);
                objoutput.flush();
                objoutput.close();
                objectStream.close();
            }
            else{ System.out.println("no file");}
            }
        }//try
        catch(Exception ex){
            System.out.println(ex);
        }
        System.out.println("Saved!");
    }///try
    catch(Exception e9){
        System.out.println( e9);
    }
    }//run
  }// end handleclient

class note implements java.io.Serializable
{
String note_data=null;
String file_name="default";
}