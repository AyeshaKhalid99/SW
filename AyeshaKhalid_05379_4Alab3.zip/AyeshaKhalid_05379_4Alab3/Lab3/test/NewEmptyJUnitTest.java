/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import lab3server.Lab3;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Rule;

/**
 *
 * @author khalid
 */
public class NewEmptyJUnitTest {
    
    public NewEmptyJUnitTest() {
    }
        @Test
  public void testing() { 
    Lab3 lb= new Lab3();
  assertEquals("file saved!", lb.sendData("testing","this is ran by junit test"));

  }

}
