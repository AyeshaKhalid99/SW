/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package lab3;

package lab3server;
import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.io.*;
/**
 *
 * @author khalid
 */
public class Lab3 {
public static JPanel panel;
public static JTextArea jt;
public static JTextArea jt1;
public static JTextArea jt2;
public static JTextArea jt3;
public static Socket sender = null;
      
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        
        JFrame frame = new JFrame();
        frame.setVisible(true);
        frame.setSize(500,500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new GridLayout(0,1));
        panel = new JPanel();
        JLabel j1=new JLabel("Enter file name:");
        JLabel j0=new JLabel("Enter file name:");
        JLabel j2=new JLabel("Enter note:");
        JLabel j3=new JLabel("Your Note:");
        JButton button = new JButton("Send Note");
        jt=new JTextArea(9,9);
        jt1=new JTextArea(2,6);
        jt2=new JTextArea(2,6);
        jt3=new JTextArea(9,9);
        panel.add(j0);panel.add(new JScrollPane(jt1));panel.add(j2);
        panel.add(new JScrollPane(jt));panel.add(button);
        panel.add(j1);
        panel.add(new JScrollPane(jt2));
        panel.add(j3);panel.add(new JScrollPane(jt3));
        
        JButton button2 = new JButton("Get Note");
        panel.add(button2);
        frame.add(panel);
        button.addActionListener (new Action1());
        button2.addActionListener (new Action2());
        panel.revalidate();
        panel.repaint();
        sender =new Socket("localhost",9001);
        // TODO code application logic here
    }//main
    static class Action1 implements ActionListener {        
        public void actionPerformed (ActionEvent e) { 
                String r=sendData(jt1.getText(),jt.getText());
        }
    }//action1
    static class Action2 implements ActionListener {        
        public void actionPerformed (ActionEvent e) { 
        get_note g= new get_note();
        g.retreive_note();
        
        }
    }//action2


public static String sendData(String fname, String text){
try{
    sender =new Socket("localhost",9001);
    Lab3 l=new Lab3();
    ObjectOutputStream out= new ObjectOutputStream(l.sender.getOutputStream());
   //  PrintWriter text_out = new PrintWriter(l.sender.getOutputStream(),true);
   // BufferedReader input = new BufferedReader(new InputStreamReader(sender.getInputStream()));
    String a=text;
    String fn=fname;
    String data = a;
    note note1= new note();
    note1.note_data=data;
    note1.file_name=fn;
    out.writeObject(note1);
    System.out.println("File saved!");
    out.flush();
    out.close();
    //ByteArrayOutputStream outContent = new ByteArrayOutputStream();
           // ByteArrayOutputStream os = new ByteArrayOutputStream(10);
       // PrintStream capture = new PrintStream(os);
       // System.setOut(capture);
      //System.setOut(new PrintStream(outContent));
    
    //System.setOut("File saved!");
//JOptionPane.showMessageDialog(null,"jj");
}//try
catch(Exception ex){
    System.out.println(ex);
}
return "file saved!";
}//function
}//class

class get_note{
void retreive_note(){
    Lab3 l1=new Lab3();
    try{
        ObjectOutputStream out2= new ObjectOutputStream(l1.sender.getOutputStream());
        ObjectInputStream objectStream2 = new ObjectInputStream(l1.sender.getInputStream());
        note note2= new note();
        note2.file_name=l1.jt2.getText();
        out2.writeObject(note2);
        out2.flush();
        note2=(note)objectStream2.readObject();
        l1.jt3.setText(note2.note_data);
        out2.close();
        objectStream2.close();
    }
    catch(Exception e){
    System.out.println(e);
    }
}//function
}//get note
class note implements java.io.Serializable
{
    String note_data=null;
    String file_name="default";
}