/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mavenproject1;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileOwnerAttributeView;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 *
 * @author khalid
 */
public class Lab7 {

 public static Hashtable<String, String> ht=new Hashtable <String, String>();
 public static Hashtable<String, String> matches=new Hashtable <String, String>();
 public static String url="not found!";
 public static String user_input="";
 
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       Scanner scanner = new Scanner (System.in);
       System.out.print("Enter file name");  
       String ff= scanner.next(); 
       user_input=ff;
       //aff=ff+".txt";
       String path="C://Users//khalid//Desktop//6th sem//test//";
       File f=new File(path);
       String[] subs = f.list();
       for(String name : subs)
        {
               // Runnable r = new Crawler(new File(path + name),ff);
            Runnable r = new Crawler(new File(path),ff);
               try{
                Thread t=new Thread(r);
                t.start();
                t.join();
               }
               catch(Exception e){}
         
}
        // System.out.println(ht);
  
         Runnable r1 = new Search(ff);
         Thread t1=new Thread(r1);
         t1.start();       
         try{
                t1.join();
               }
               catch(Exception e){}
     //   System.out.println("Your File:"+url);
        System.out.println("Indexed table:"+Lab7.ht); 
        System.out.println("Your required and matched files: "+Lab7.matches);
    }
    
public String give_extension(String fullFIle){
String[] extension= fullFIle.split("\\.(?=[^\\.]+$)");
return extension[1];
}    
    
    
    
} //main class

class Crawler implements Runnable{
    private Thread t;
    private File f1;
    String filename;
   //  public static Hashtable<String, String> ht=new Hashtable <String, String>();
Crawler(File directory, String fileNameToSearch){
    f1=directory;
    filename=fileNameToSearch;

}//const
public void run(){

searchDirectory(f1,filename);
}//run
  private String fileNameToSearch;
  private List<String> result = new ArrayList<String>();
  public Enumeration f_name;
  public String getFileNameToSearch() {
	return fileNameToSearch;
  }
    public Hashtable get_Hashtable() {
	return Lab7.ht;
  }
  public void setFileNameToSearch(String fileNameToSearch) {
	this.fileNameToSearch = fileNameToSearch;
  }

  public List<String> getResult() {
	return result;
  }

  public void searchDirectory(File directory, String fileNameToSearch) {
	setFileNameToSearch(fileNameToSearch);
	if (directory.isDirectory()) {
	    search(directory);
	} else {
        Lab7.ht.put(directory.getName().replaceFirst("[.][^.]+$", ""),directory.getAbsoluteFile()+" ");
	}
  }//search directory
  
  
  public int countFiles(File folder, int count) {
    File[] files = folder.listFiles();
    for (File file: files) {
        if (file.isFile()) {
            count++;
        } else {
            countFiles(file, count);
        }
    }

    return count;
}
  
  
  
  
  private void search(File file) {

    	if (file.isDirectory()) {
            Lab7.ht.put(file.getName().replaceFirst("[.][^.]+$", ""),file.getAbsoluteFile()+" ");     
            Lab7.ht.put("files="+countFiles(file, 0),file.getAbsoluteFile()+" ");
                //do you have permission to read this directory?	
    	    if (file.canRead()) {
    		for (File temp : file.listFiles()) {
    		    if (temp.isDirectory()) {
                       search(temp);
    		    } else {
                        try{
                        Path path = Paths.get(temp.getAbsoluteFile().toString());
                                 BasicFileAttributes bfa = Files.readAttributes(path,BasicFileAttributes.class);
                                 FileOwnerAttributeView ow = Files.getFileAttributeView(path, FileOwnerAttributeView.class);
                                Lab7.ht.put(temp.getName().replaceFirst("[.][^.]+$", ""),temp.getAbsoluteFile()+" ");
                                Lab7.ht.put(bfa.size()+"bytes",""+temp.getAbsoluteFile());
                                Lab7.ht.put(""+bfa.creationTime(),""+temp.getAbsoluteFile());
                                Lab7.ht.put(""+ow.getOwner(),""+temp.getAbsoluteFile());
             
                     // Lab7.ht.put(""+bfa.lastAccessTime(),""+temp.getAbsoluteFile());
                                String[] ext = temp.getName().split("\\.(?=[^\\.]+$)");
                               Lab7.ht.put(ext[1],temp.getAbsoluteFile()+" ");
                        }
                        catch(Exception e){}
    		}
    	    }
    	 } else {
    		System.out.println(file.getAbsoluteFile() + "Permission Denied");
    	 }
          }
        
      }//search
}//crawler 


class Search implements Runnable {
    private String name;
    Search(String file_to_search){
    name=file_to_search;
    }//cons
    public void run(){
        get_file_path(name);
}//run

    void get_file_path(String s){
    Pattern r = Pattern.compile(Lab7.user_input);
     Set<String> keys = Lab7.ht.keySet();
        for(String key: keys){
           Matcher m = r.matcher(key);
            if( m.find()){
                Lab7.matches.put(""+key,"--->"+Lab7.ht.get(key));
            }
            //}//match key
        }     
}
}