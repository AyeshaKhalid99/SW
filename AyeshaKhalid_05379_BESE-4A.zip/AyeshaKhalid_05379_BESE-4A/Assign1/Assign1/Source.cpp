#include <cstdlib>
#include <iostream>
#include<cstring>

using namespace std;


////////******COPIED POINTERS******/////////


 class StringBuffer{
 private:
    char* _strbuf;                                   //buffer to store the original string
    int _length;                                       //length of the string

public :
    StringBuffer();  //default constructor
    ~StringBuffer();                //destructor; would delete the allocated buffer
    StringBuffer(const StringBuffer&);              //constructor for shallow copying
    StringBuffer(char*,int);   //constructor to convert a char* to StringBuffer
    char charAt(int) const;   //returns the character at the passed index
    int length() const;                            //returns the length of the buffer
    void reserve(int);                             //allocates memory for the string, according to the passed character length
    void append(char);                          //appends a single character at the end
	void smartCopy(StringBuffer* newString, int length);
	void display(char* name,const StringBuffer&);


};

 StringBuffer:: StringBuffer(){
	this->_strbuf = NULL;
    this->_length = 0;
 }
  StringBuffer::~StringBuffer(){
	  if( this->_strbuf!=NULL){
		delete[] this->_strbuf;
		this->_strbuf=NULL;
		cout << "Done releasing memory!" << endl;
	  }
 }
 void StringBuffer::reserve(int space){
	cout << "Allocating memory!" << endl;
	_strbuf = new char[space];
 }
 int StringBuffer::length()const{
	 return this->_length;
 }

 StringBuffer:: StringBuffer(char* newString,int len){
	_length = len;
    _strbuf = new char[len+1];
	//strncpy(_strbuf, newString, _length);
	for (int i=0;i<len;i++){
        _strbuf[i] = newString[i];
	 }
	_strbuf[_length ] = '\0';
	 
 }

 StringBuffer:: StringBuffer(const StringBuffer& source){
     cout << "copying.." << endl;
	 this->_strbuf = new char[source.length()+1];
	 this->_length = source.length();
	 for (int i=0;i<source.length();i++){
        _strbuf[i] = source._strbuf[i];
	 }
	this->_strbuf[_length ] = '\0';
 }  



 void StringBuffer::smartCopy(StringBuffer* newString, int length) {
      int shorterLength = 0;
    (this->_length < newString->_length) ? shorterLength = this->_length : shorterLength = newString->_length;
    int it = 0;
    while (it < shorterLength) {
        *_strbuf++ = *(newString->_strbuf)++;
        it++;
    }

}

 void StringBuffer::append(char c) {
	 cout << "appending.." << endl;
	_length=_length+1;
	_strbuf=(char *)realloc(_strbuf,_length+1);
	_strbuf[this->_length - 1] = c;
	_strbuf[_length ] = '\0';
}
 void  StringBuffer::display(char* name,const StringBuffer& obj)
{
   cout << "Length of obj " << name<<" is: "<<obj.length()<<" and value is: "<<obj._strbuf<<endl;

}



 int main()
{
	char *c="This is a test String.";
	StringBuffer sb1 (c,22);
	sb1.display("sb1",sb1);
	StringBuffer sb2 (sb1);
    sb2.display("sb2",sb2);
	sb1.append('!');
	sb2.append('*');
	sb1.display("sb1",sb1);
	sb2.display("sb2",sb2);
	sb1.~StringBuffer();
	sb2.~StringBuffer();
	system("pause");
	return 0;
}

