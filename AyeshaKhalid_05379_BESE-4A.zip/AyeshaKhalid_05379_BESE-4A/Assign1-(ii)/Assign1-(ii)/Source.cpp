#include <cstdlib>
#include <iostream>
#include<cstring>

using namespace std;
////////******OWNED POINTERS******/////////


 class StringBuffer{
 private:
    char* _strbuf;                                   //buffer to store the original string
    int _length;                                       //length of the string
	int allowed_deletion;

public :
    StringBuffer();  //default constructor
    ~StringBuffer();                //destructor; would delete the allocated buffer
    StringBuffer(const StringBuffer&);              //constructor for shallow copying
    StringBuffer(char*,int);   //constructor to convert a char* to StringBuffer
    char charAt(int) const;   //returns the character at the passed index
    int length() const;                            //returns the length of the buffer
    void reserve(int);                             //allocates memory for the string, according to the passed character length
    void append(char);                          //appends a single character at the end
	void smartCopy(char* newString, int length);
	void display(char* name,const StringBuffer&);


};

 StringBuffer:: StringBuffer(){
	this->_strbuf = NULL;
    this->_length = 0;
	this->allowed_deletion = 0;
 }
  StringBuffer::~StringBuffer(){
		
	  if(this->allowed_deletion==1){
		  if(_strbuf!=NULL){
			  delete[] _strbuf;
		      _strbuf=NULL;
			  cout << "Memory released!!" << endl;
		  }
	  }
	  else{
	  cout << "You are not the owner!!" << endl;
	  }
	
 }
 void StringBuffer::reserve(int space){
	cout << "Allocating memory!" << endl;
	_strbuf = new char[space];
 }
 int StringBuffer::length()const{
	 return this->_length;
 }

 StringBuffer:: StringBuffer(char* newString,int len){
	 this->allowed_deletion=0;
	_length = len;
    _strbuf = new char[len+1];
	for (int i=0;i<len;i++){
        _strbuf[i] = newString[i];
	 }
	this->_strbuf[_length ] = '\0';

 }

 StringBuffer:: StringBuffer(const StringBuffer& source){
     cout << "copying.." << endl;
	this->allowed_deletion=1;
	 this->_strbuf = new char[source.length()+1];
	 this->_length = source.length();
	 this->_strbuf=source._strbuf;
	this->_strbuf[_length ] = '\0';
 }  



 void StringBuffer::smartCopy(char* newString, int length) {
    this->_length = length;
    int it = 0;
    while (it < length) {
        *_strbuf++ = *newString++;
        it++;
    }

}

 void StringBuffer::append(char c) {
	 cout << "appending.." << endl;
	this->_length=_length+1;
	this->_strbuf=(char *)realloc(_strbuf,_length+1);
	_strbuf[this->_length - 1] = c;
	_strbuf[_length ] = '\0';
}
 void  StringBuffer::display(char* name,const StringBuffer& obj)
{
   cout << "Length of obj " << name<<" is: "<<obj.length()<<" and value is: "<<obj._strbuf<<endl;

}



 int main()
{
	char *c="Testing owned pointers";
	StringBuffer sb1 (c,22);
	sb1.display("sb1",sb1);
	StringBuffer sb2 (sb1);
    sb2.display("sb2",sb2);
	sb1.append('.');
	sb2.append('!');
	sb1.display("sb1",sb1);
	sb2.display("sb2",sb2);
	//sb1.~StringBuffer();
	sb2.~StringBuffer();
	
	system("pause");
	return 0;
}

